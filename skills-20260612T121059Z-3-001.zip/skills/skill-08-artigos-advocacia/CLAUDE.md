# CLAUDE.md — Skill 08: Elaborar Artigos para Advocacia

## Objetivo

Produzir artigos prontos para o blog do escritório, otimizados para leitor leigo e para indicação por IA generativa (GEO), no nicho Família/Sucessões/Imobiliário.

---

## Contexto Necessário

Solicitar ao usuário antes de iniciar, caso não fornecido:

- Tema central
- Dúvida real do cliente que motiva o tema
- Palavra-chave principal e 3 secundárias
- Tom do escritório (acolhedor, técnico-acessível, sem juridiquês, sem alarmismo)
- Tamanho-alvo (padrão: 1.000–1.500 palavras)

---

## Instruções de Execução

1. Abrir com a pergunta ou situação real do cliente
2. Estruturar em H2 e H3 escaneáveis
3. Explicar conceitos jurídicos em linguagem leiga, com 1 exemplo prático por bloco
4. Citar legislação aplicável uma vez, com referência clara, sem transcrever artigo inteiro
5. Inserir bloco "Quando procurar um advogado" próximo ao final
6. Encerrar com CTA suave (consulta, agendamento, contato)
7. Otimizar para GEO: respostas diretas em frases curtas, listas, tabelas comparativas, FAQ ao final com 4 a 6 perguntas
8. Gerar título principal + 2 alternativos + meta-description (até 155 caracteres)

---

## Formato de Saída

**Bloco 1 — Metadados SEO**
- Título principal:
- Título alternativo 1:
- Título alternativo 2:
- Meta-description (máx. 155 caracteres):
- Palavra-chave principal:
- Palavras-chave secundárias:

**Bloco 2 — Artigo completo** (em markdown, com H2/H3, listas e exemplos)

**Bloco 3 — FAQ** (4 a 6 perguntas e respostas diretas)

**Bloco 4 — Sugestões de imagem** (3 ideias de ilustração)

**Bloco 5 — Ganchos para Instagram** (2 ideias de post derivados do artigo)

---

## Casos de Uso

- "O que acontece com os bens no divórcio?" → artigo sobre partilha para leigos
- "Meu pai morreu sem testamento, o que faço?" → artigo sobre inventário
- "Posso regularizar um imóvel sem escritura?" → artigo sobre usucapião e regularização

---

## Limitações

- Linguagem sempre acessível — sem juridiquês pesado
- Nunca identificar partes ou casos reais
- Verificar atualização legislativa antes de finalizar
- Todo artigo vai para validação da Nilma antes de publicar — nunca presumir aprovação automática

---

## Dependências Documentais

- DOC-0-perfil-do-escritorio.docx (tom, nicho, posicionamento)
- DOC-0-glossario-do-escritorio.docx (nomenclaturas e termos padronizados)

# Ficha da Skill

**Nome:** Skill 08 — Elaborar artigos para advocacia

**Objetivo:** Produzir artigos prontos para o blog do escritório, otimizados para leitor leigo e para indicação por IA generativa (GEO), no nicho Família/Sucessões/Imobiliário.

**Quando utilizar:**
- Quando quiser criar um artigo para o blog
- Quando quiser transformar uma dúvida frequente de cliente em conteúdo
- Quando quiser texto SEO/GEO para atrair clientes organicamente

**Entradas esperadas:**
- Tema central
- Dúvida real do cliente que motiva o tema
- Palavra-chave principal e 3 secundárias
- Tom do escritório (acolhedor, técnico-acessível, sem juridiquês, sem alarmismo)
- Tamanho-alvo (padrão: 1.000–1.500 palavras)

**Saídas esperadas:**
- Título principal + 2 alternativos
- Meta-description (máx. 155 caracteres)
- Artigo completo em markdown (H2/H3, listas, exemplos)
- FAQ final (4 a 6 perguntas)
- Sugestão de 3 imagens/ilustrações
- Sugestão de 2 ganchos para post no Instagram derivados do artigo

**Projetos que utilizam a skill:**
- Projeto Comercial (Tarefa 01 — Artigos mensais)
- Projeto Marketing

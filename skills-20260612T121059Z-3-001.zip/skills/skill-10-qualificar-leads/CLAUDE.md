# CLAUDE.md — Skill 10: Qualificar Leads

## Objetivo

Apoiar Marcela na triagem do lead que chega pelo WhatsApp, indicando se vira atendimento gratuito 30min, consulta paga R$ 600, reagendamento ou descarte cordial.

---

## Contexto Necessário

Solicitar ao usuário antes de iniciar, caso não fornecido:

- Mensagens trocadas com o lead até o momento
- Respostas do lead às perguntas-chave do fluxograma
- Sinais sobre capacidade econômica, urgência e tipo de demanda
- Critérios de NO-GO do escritório

---

## Instruções de Execução

1. Classificar o lead em:
   - **(a)** Fora do nicho
   - **(b)** Dentro do nicho com baixa capacidade econômica
   - **(c)** Dentro do nicho com capacidade adequada
   - **(d)** Dentro do nicho com alta capacidade e alto valor estratégico
2. Identificar urgência real (prazo processual? medida urgente? só dúvida?)
3. Avaliar fit com posicionamento (caso recorrente do escritório? alto valor estratégico?)
4. Sugerir próxima ação:
   - Descarte cordial
   - Atendimento gratuito 30min
   - Consulta paga R$ 600
   - Encaminhamento a parceiro
5. Redigir mensagem-resposta pronta para a Marcela enviar (no tom da Nilma)
6. Anotar pontos a registrar no Astrea sobre o lead

---

## Formato de Saída

**Classificação do lead:** (a) / (b) / (c) / (d)

**Justificativa:** (3 frases)

**Próxima ação:** [Descarte cordial / Atendimento gratuito 30min / Consulta paga R$600 / Encaminhamento a parceiro]

**Mensagem pronta para envio:**
```
[Copie e envie para o lead]
```

**Campos para o Astrea:**
- Nome:
- Canal de origem:
- Tipo de demanda:
- Classificação:
- Próxima ação:
- Motivo de descarte (se NO-GO):

---

## Casos de Uso

- Lead que chegou pedindo ajuda com herança e mencionou bens de alto valor → (d) consulta paga
- Lead que quer divórcio mas mora em outra cidade e fora do litoral SP → verificar se o escritório atende
- Lead pedindo orientação gratuita sobre pensão alimentícia → avaliar urgência e capacidade econômica

---

## Limitações

- Classificação sempre baseada nos critérios do escritório — nunca improvisar encaminhamento
- Motivos de NO-GO sempre comunicados ao lead de forma cordial e sem exposição dos critérios internos
- Nunca filtrar leads quentes por conta própria — alertar Nilma imediatamente
- Nunca identificar partes em comunicações externas

---

## Dependências Documentais

- DOC-0-perfil-do-escritorio.docx (ticket mínimo, perfil ideal e critérios de NO-GO)
- DOC-0-fluxograma-de-atendimento.docx (perguntas-chave de triagem e mensagens-padrão)
- DOC-0-glossario-do-escritorio.docx (nomenclaturas corretas)

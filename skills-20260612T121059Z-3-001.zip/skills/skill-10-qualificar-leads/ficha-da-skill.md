# Ficha da Skill

**Nome:** Skill 10 — Qualificar leads

**Objetivo:** Apoiar Marcela na triagem do lead que chega pelo WhatsApp, indicando se vira atendimento gratuito 30min, consulta paga R$ 600, reagendamento ou descarte cordial.

**Quando utilizar:**
- Quando um contato novo chegar pelo WhatsApp ou outro canal
- Quando precisar classificar um lead antes de decidir o encaminhamento
- Quando precisar de mensagem pronta para responder ao lead
- Quando precisar registrar o lead no Astrea

**Entradas esperadas:**
- Mensagens trocadas com o lead até o momento
- Respostas do lead às perguntas-chave do fluxograma
- Sinais sobre capacidade econômica, urgência e tipo de demanda
- Critérios de NO-GO do escritório

**Saídas esperadas:**
- Classificação do lead (a/b/c/d)
- Justificativa em 3 frases
- Próxima ação recomendada
- Mensagem pronta para envio (em bloco copiável)
- Campos a preencher no Astrea

**Projetos que utilizam a skill:**
- Projeto Comercial (uso principal — Marcela)
- Projeto Procedimentos (consulta ao fluxograma)

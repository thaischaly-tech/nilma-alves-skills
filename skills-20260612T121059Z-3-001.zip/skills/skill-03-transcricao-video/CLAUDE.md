# CLAUDE.md — Skill 03: Transcrição de Vídeo

## Objetivo

Transformar gravação (consulta, audiência, reunião interna, conteúdo gravado pela Nilma) em texto estruturado, pesquisável e reutilizável — para peça, ata, conteúdo ou alimentação de outras skills.

---

## Contexto Necessário

Solicitar ao usuário antes de iniciar, caso não fornecido:

- Arquivo de vídeo/áudio ou link
- Tipo do conteúdo: consulta com cliente / audiência / reunião interna / gravação para conteúdo
- Finalidade da transcrição (peça, ata, post, treinamento de equipe)

---

## Instruções de Execução

1. Transcrever integralmente, identificando interlocutores quando houver mais de um
2. Marcar timestamps a cada mudança de tema
3. Gerar resumo executivo de 5 a 10 linhas
4. Extrair: decisões tomadas, prazos mencionados, próximos passos, pontos sensíveis (dados pessoais, valores, nomes de terceiros)
5. Sinalizar trechos com baixa confiança de transcrição
6. Adaptar saída ao uso final:
   - Se for ata: formatar com cabeçalho, decisões e responsáveis
   - Se for conteúdo: separar ganchos e blocos aproveitáveis
   - Se for peça: destacar fatos jurídicos relevantes

---

## Formato de Saída

**Bloco 1 — Resumo executivo** (5 a 10 linhas)

**Bloco 2 — Decisões / Prazos / Responsáveis**

| Decisão/Item | Prazo | Responsável |
|---|---|---|

**Bloco 3 — Transcrição completa** (com timestamps e nomes dos interlocutores)

**Bloco 4 — Trechos com baixa confiança** (lista com indicação do trecho e timestamp)

---

## Casos de Uso

- Consulta gravada com cliente → fatos para a inicial
- Audiência de divórcio → ata processual
- Reunião de equipe → ata com ações e prazos
- Nilma gravando explicação sobre herança → roteiro de Reel

---

## Limitações

- Dados pessoais identificados na transcrição (CPF, endereço, valores, nomes de terceiros) devem ser sinalizados como sensíveis
- Não interpretar juridicamente o conteúdo da transcrição — apenas transcrever e estruturar
- Ferramenta de referência do escritório para transcrição: Taqtic

---

## Dependências Documentais

- DOC-0-perfil-do-escritorio.docx (tom e nomenclaturas do escritório)
- DOC-0-glossario-do-escritorio.docx (termos padronizados)

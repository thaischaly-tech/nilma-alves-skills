# Ficha da Skill

**Nome:** Skill 03 — Transcrição de vídeo

**Objetivo:** Transformar gravação (consulta, audiência, reunião interna, conteúdo gravado pela Nilma) em texto estruturado, pesquisável e reutilizável — para peça, ata, conteúdo ou alimentação de outras skills.

**Quando utilizar:**
- Consulta com cliente gravada → para extrair fatos para a peça
- Audiência gravada → para ata e diagnóstico processual
- Reunião interna → para ata com decisões e responsáveis
- Gravação da Nilma para conteúdo → para roteiro ou artigo

**Entradas esperadas:**
- Arquivo de vídeo/áudio ou link
- Tipo do conteúdo: consulta com cliente / audiência / reunião interna / gravação para conteúdo
- Finalidade da transcrição (peça, ata, post, treinamento de equipe)

**Saídas esperadas:**
- Resumo executivo (5 a 10 linhas)
- Tabela: decisões / prazos / responsáveis
- Transcrição completa com timestamps e identificação de interlocutores
- Trechos com baixa confiança de transcrição (lista)

**Projetos que utilizam a skill:**
- Projeto Operacional (uso principal — Catharine)
- Projeto Marketing (conteúdos gravados pela Nilma)

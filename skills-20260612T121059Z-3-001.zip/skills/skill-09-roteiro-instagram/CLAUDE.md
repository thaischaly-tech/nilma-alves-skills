# CLAUDE.md — Skill 09: Elaborar Roteiro para Instagram

## Objetivo

Roteiro pronto para gravação (Reels, story longa ou feed) no nicho de Família/Sucessões, no tom da Nilma, com gancho forte e CTA definido.

---

## Contexto Necessário

Solicitar ao usuário antes de iniciar, caso não fornecido:

- Tema/dor do público
- Formato (Reel até 90s, story longa, carrossel)
- CTA desejado (consulta, salvar, comentar, compartilhar, DM)
- Tom: acolhedor, sem melancolia, sem alarmismo

---

## Instruções de Execução

1. Abrir com gancho de alto impacto nos 3 primeiros segundos (pergunta, afirmação contraintuitiva ou cena cotidiana)
2. Conectar gancho à dor concreta do espectador
3. Desenvolver 1 ideia central — não duas. Uma frase de cada vez
4. Aplicar 2 a 3 gatilhos mentais coerentes (autoridade, prova, urgência leve, pertencimento, reciprocidade)
5. Encerrar com CTA explícito
6. Linguagem falada, frases curtas, prontas para teleprompter
7. Mínimo 1min30s para Reels (texto corrido)
8. Sugerir descrição do post + 8 hashtags

---

## Formato de Saída

**Bloco 1 — Roteiro corrido** (pronto para teleprompter — 1 bloco contínuo, sem interrupções)

[indicações de cena em colchetes quando necessário]

**Bloco 2 — Descrição do post** (para o caption do Instagram)

**Bloco 3 — Hashtags** (8 hashtags profissionais e específicas)

**Bloco 4 — Variações de gancho** (3 alternativas para o início do vídeo)
1. Gancho alternativo 1
2. Gancho alternativo 2
3. Gancho alternativo 3

---

## Casos de Uso

- "O que acontece com a herança quando não há testamento?" → Reel educativo sobre inventário
- "Você sabia que pode perder o direito à pensão alimentícia?" → Story de alerta
- "3 erros que as pessoas cometem no divórcio" → Reel de lista

---

## Limitações

- Tom: nunca alarmista, nunca melancólico — sempre acolhedor e técnico-acessível
- Linguagem falada — nunca juridiquês pesado
- Nunca identificar partes ou casos reais
- Todo roteiro vai para validação da Nilma antes de gravar — nunca presumir aprovação automática

---

## Dependências Documentais

- DOC-0-perfil-do-escritorio.docx (tom de voz, público-alvo, posicionamento)
- DOC-0-glossario-do-escritorio.docx (nomenclaturas padronizadas)

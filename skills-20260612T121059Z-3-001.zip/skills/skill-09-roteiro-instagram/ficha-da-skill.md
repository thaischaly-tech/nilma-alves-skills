# Ficha da Skill

**Nome:** Skill 09 — Elaborar roteiro para Instagram

**Objetivo:** Roteiro pronto para gravação (Reels, story longa ou feed) no nicho de Família/Sucessões, no tom da Nilma, com gancho forte e CTA definido.

**Quando utilizar:**
- Quando quiser um roteiro de Reel ou story
- Quando quiser conteúdo pronto para gravar e publicar no Instagram
- Quando tiver um tema e precisar transformá-lo em vídeo

**Entradas esperadas:**
- Tema/dor do público
- Formato (Reel até 90s, story longa, carrossel)
- CTA desejado (consulta, salvar, comentar, compartilhar, DM)
- Tom: acolhedor, sem melancolia, sem alarmismo

**Saídas esperadas:**
- Roteiro corrido (1 bloco), pronto para teleprompter (mín. 1min30s para Reels)
- Sugestão de cenas/cortes (em colchetes)
- Descrição do post
- Hashtags (8)
- Variações de gancho (3 alternativas)

**Projetos que utilizam a skill:**
- Projeto Marketing (uso principal)

# Ficha da Skill

**Nome:** Skill 04 — Analisar peça como juiz

**Objetivo:** Submeter a peça à leitura crítica de um magistrado da vara competente antes do protocolo, expondo fragilidades técnicas, retóricas e probatórias.

**Quando utilizar:**
- Antes de protocolar qualquer peça relevante
- Quando houver dúvida sobre a força argumentativa da peça
- Quando quiser antecipar pontos de ataque da parte adversa
- Quando quiser uma estimativa de probabilidade de procedência

**Entradas esperadas:**
- Peça em versão final (ou quase final)
- Tipo de peça (inicial, contestação, recurso, alegações finais, embargos)
- Vara/competência (família, sucessões, cível, JEC)
- Pretensão e pedidos

**Saídas esperadas:**
- Veredito do juiz (parágrafo único)
- Top 5 fragilidades, em ordem de gravidade
- Top 3 acertos (manter)
- Sugestões de melhoria divididas por bloco da peça (fatos / direito / pedidos / provas)
- Estimativa de procedência (%) com justificativa

**Projetos que utilizam a skill:**
- Projeto Operacional (uso principal — Catharine e Nilma)

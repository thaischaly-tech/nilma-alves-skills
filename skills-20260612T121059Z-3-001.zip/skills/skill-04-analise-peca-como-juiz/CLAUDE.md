# CLAUDE.md — Skill 04: Analisar Peça como Juiz

## Objetivo

Submeter a peça à leitura crítica de um magistrado da vara competente antes do protocolo, expondo fragilidades técnicas, retóricas e probatórias.

---

## Contexto Necessário

Solicitar ao usuário antes de iniciar, caso não fornecido:

- Peça em versão final (ou quase final)
- Tipo de peça (inicial, contestação, recurso, alegações finais, embargos)
- Vara/competência (família, sucessões, cível, JEC)
- Pretensão e pedidos

---

## Instruções de Execução

1. Ler a peça assumindo o papel de juiz de família/sucessões com sobrecarga de processos
2. Avaliar: clareza dos pedidos, fundamentação legal, coerência fática, prova juntada vs. afirmada, jurisprudência citada (atual e aplicável)
3. Identificar contradições internas e pontos de ataque óbvios pela parte adversa
4. Apontar onde o juiz desistiria de ler ou perderia interesse
5. Apontar onde falta sinalização visual (subtítulos, destaques, síntese)
6. Sugerir cortes, reforços e reorganizações
7. Estimar a probabilidade de procedência total / parcial / improcedência com base apenas no que está escrito

---

## Formato de Saída

**Bloco 1 — Veredito do juiz** (parágrafo único — impressão geral antes da análise detalhada)

**Bloco 2 — Top 5 fragilidades** (em ordem de gravidade)
1. [fragilidade] — [impacto]
2. ...

**Bloco 3 — Top 3 acertos** (manter sem alteração)
1. ...

**Bloco 4 — Sugestões de melhoria por bloco**
- Fatos:
- Direito:
- Pedidos:
- Provas:

**Bloco 5 — Estimativa de procedência**
- Procedência total: X%
- Procedência parcial: X%
- Improcedência: X%
- Justificativa:

---

## Casos de Uso

- Inicial de inventário antes do protocolo → identificar fragilidades de prova
- Recurso de apelação → avaliar se a argumentação supera a sentença
- Contestação em divórcio litigioso → checar coerência e pontos de ataque do autor

---

## Limitações

- Não inventar jurisprudência — apenas avaliar a que foi citada na peça
- Estimativa de procedência é exercício de análise técnica, não promessa de resultado
- Toda saída exige revisão e validação da Nilma antes de qualquer ação

---

## Dependências Documentais

- DOC-0-perfil-do-escritorio.docx (padrão de qualidade de peças do escritório)

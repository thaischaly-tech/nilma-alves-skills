# Ficha da Skill

**Nome:** Skill 12 — Tarefas programadas automáticas

**Objetivo:** Skill orquestradora que dispara as tarefas recorrentes do escritório nos dias e horários combinados, gera os outputs e endereça aos responsáveis (Catharine, Marcela, Nilma).

**Quando utilizar:**
- Quando todas as demais skills já produzem output padronizado e estável
- Para automatizar a execução das tarefas recorrentes
- Para gerar log de execução e rastrear o que foi entregue e o que está pendente

**Entradas esperadas:**
- Calendário de tarefas recorrentes (diárias, semanais, mensais)
- Responsável por cada tarefa
- Canal de entrega (e-mail interno, Astrea, pasta compartilhada, WhatsApp interno)
- Padrão de output esperado em cada tarefa

**Saídas esperadas:**
- Log de execução do dia: tabela com tarefa | data | status | responsável | observações
- Saídas individuais de cada tarefa endereçadas ao responsável correto
- Lista de pendências/falhas para Nilma revisar

**Projetos que utilizam a skill:**
- Todos os projetos (skill orquestradora transversal)

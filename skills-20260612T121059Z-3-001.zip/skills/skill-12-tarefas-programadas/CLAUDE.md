# CLAUDE.md — Skill 12: Tarefas Programadas Automáticas

## Objetivo

Skill orquestradora que dispara as tarefas recorrentes do escritório nos dias e horários combinados, gera os outputs e endereça aos responsáveis (Catharine, Marcela, Nilma).

> Esta skill só deve ser ativada após as demais skills (01 a 11) já estarem funcionando de forma estável e produzindo outputs padronizados. Ativação prematura gera entregas inconsistentes.

---

## Contexto Necessário

Solicitar ao usuário antes de iniciar, caso não fornecido:

- Calendário de tarefas recorrentes (diárias, semanais, mensais)
- Responsável por cada tarefa
- Canal de entrega (e-mail interno, Astrea, pasta compartilhada, WhatsApp interno)
- Padrão de output esperado em cada tarefa

---

## Calendário de Tarefas Recorrentes do Escritório

| Frequência | Tarefa | Responsável | Canal de entrega |
|---|---|---|---|
| Diária (fim do expediente) | Tarefa 03 — Triagem de leads | Marcela | WhatsApp interno + Astrea |
| 1º dia útil do mês | Tarefa 01 — Artigos mensais | Catharine (revisão) + Nilma (validação) | E-mail interno |
| Dia 5 do mês | Tarefa 01 Gestão — Relatórios mensais | Nilma | E-mail interno |
| Dia 7 do mês | Tarefa 04 — Fechamento comercial | Nilma | Chat do projeto |
| Dia 7 do mês | Tarefa 01 Financeiro — Fechamento financeiro | Nilma | Chat do projeto |
| Último dia útil do mês | Tarefa 02 — Pesquisa de mercado | Nilma | Relatório no chat |

---

## Instruções de Execução

1. Para cada tarefa programada: confirmar gatilho (data/hora ou evento)
2. Coletar inputs necessários da fonte correta (Astrea, redes sociais, planilha de leads)
3. Executar a skill correspondente (01 a 11)
4. Formatar output no padrão esperado para o canal de entrega
5. Endereçar ao responsável com assunto padronizado
6. Registrar log: tarefa | data | status | responsável | observações
7. Em caso de falha de input, sinalizar e pausar — não improvisar dado

---

## Formato de Saída

**Log de execução do dia:**

| Tarefa | Data | Status | Responsável | Observações |
|---|---|---|---|---|
| Tarefa 03 — Triagem de leads | [data] | ✅ Concluída / ⚠️ Pendente / ❌ Falha | Marcela | [observação] |

**Saídas individuais de cada tarefa** (endereçadas ao responsável correto — formato específico de cada tarefa)

**Lista de pendências/falhas para Nilma:** (itens que precisam de atenção)
- item 1
- item 2

---

## Casos de Uso

- Disparar automaticamente a triagem diária de leads ao fim do expediente
- Gerar os relatórios mensais no dia 5 sem intervenção manual
- Registrar log de execução para rastreabilidade

---

## Limitações

- Nunca executar sem os inputs necessários — sinalizar e aguardar
- Nunca improvisar dados ausentes
- Nunca endereçar dados financeiros a destinatários fora da Nilma
- Toda saída de avaliação de pessoas (gestão) é exclusiva da Nilma

---

## Dependências Documentais

- Todas as skills (01 a 11) devem estar funcionando antes de ativar esta
- DOC-0-perfil-do-escritorio.docx (responsáveis e canais de comunicação)
- Calendário editorial vigente (para tarefas de marketing)

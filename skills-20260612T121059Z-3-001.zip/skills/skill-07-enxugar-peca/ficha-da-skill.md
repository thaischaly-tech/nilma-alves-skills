# Ficha da Skill

**Nome:** Skill 07 — Enxugar peça grande

**Objetivo:** Reduzir extensão da peça mantendo (ou aumentando) força argumentativa. Eliminar redundância, prolixidade e juridiquês inflado.

**Quando utilizar:**
- Quando a peça estiver muito longa e precisar ser reduzida
- Quando quiser cortar sem perder técnica
- Quando quiser reescrever trechos com linguagem mais objetiva

**Entradas esperadas:**
- Peça atual (integralmente)
- Tamanho-alvo (em páginas ou caracteres) ou diretriz "menor possível sem perder técnica"
- Pontos inegociáveis (teses, fundamentos, pedidos que não podem ser removidos)

**Saídas esperadas:**
- Versão enxuta completa
- Tabela resumo: original (caracteres/páginas) → final (caracteres/páginas)
- Lista de cortes principais (com justificativa em 1 linha cada)
- Pontos onde a redução pediria validação humana

**Projetos que utilizam a skill:**
- Projeto Operacional (uso principal — Catharine e Nilma)

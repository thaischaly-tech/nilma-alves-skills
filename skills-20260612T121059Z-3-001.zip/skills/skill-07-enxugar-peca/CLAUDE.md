# CLAUDE.md — Skill 07: Enxugar Peça Grande

## Objetivo

Reduzir extensão da peça mantendo (ou aumentando) força argumentativa. Eliminar redundância, prolixidade e juridiquês inflado.

---

## Contexto Necessário

Solicitar ao usuário antes de iniciar, caso não fornecido:

- Peça atual (integralmente)
- Tamanho-alvo (em páginas ou caracteres) ou diretriz "menor possível sem perder técnica"
- Pontos inegociáveis (teses, fundamentos, pedidos)

---

## Instruções de Execução

1. Identificar e cortar: parágrafos repetidos, transcrição excessiva de doutrina, jurisprudência redundante, citações de artigos com texto legal completo (substituir por referência)
2. Reescrever frases longas em frases curtas e diretas
3. Substituir floreios e expressões cerimoniosas por linguagem clara
4. Manter intactos: tese, fatos essenciais, pedidos e fundamento legal central
5. Garantir que nenhuma alegação fática perca sua respectiva prova
6. Reorganizar quando o corte permitir fluxo mais lógico
7. Apresentar diff resumido (o que saiu, o que ficou, o que foi reescrito)

---

## Formato de Saída

**Bloco 1 — Versão enxuta completa** (peça inteira revisada)

**Bloco 2 — Tabela resumo**

| | Original | Final |
|---|---|---|
| Páginas | X | Y |
| Caracteres | X | Y |

**Bloco 3 — Lista de cortes principais**

| Trecho cortado/alterado | Justificativa |
|---|---|
| [descrição] | [motivo em 1 linha] |

**Bloco 4 — Pontos para validação humana** (onde o corte pode ser questionável)
- item 1
- item 2

---

## Casos de Uso

- Inicial de 40 páginas → reduzir para 20 sem perder técnica
- Contestação redundante → eliminar parágrafos repetidos e transcrições desnecessárias
- Recurso muito longo → focar nos fundamentos de reforma e cortar o acessório

---

## Limitações

- Não cortar pedidos sem autorização explícita da Nilma
- Não alterar tese jurídica central — apenas a forma de apresentação
- Toda versão enxuta é minuta — exige revisão final antes do protocolo

---

## Dependências Documentais

- DOC-0-perfil-do-escritorio.docx (padrão de peças e tom do escritório)

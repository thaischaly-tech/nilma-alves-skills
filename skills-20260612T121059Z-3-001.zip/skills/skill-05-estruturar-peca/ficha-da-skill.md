# Ficha da Skill

**Nome:** Skill 05 — Estruturar peça para protocolo

**Objetivo:** Gerar esqueleto técnico padronizado de peça, alinhado ao tom do escritório, pronto para Catharine preencher.

**Quando utilizar:**
- Quando precisar montar a estrutura de uma peça do zero
- Quando quiser um modelo técnico de inicial, contestação ou recurso
- Quando precisar organizar os blocos de uma peça antes de redigir

**Entradas esperadas:**
- Tipo de peça e vara
- Partes (qualificação básica)
- Fatos resumidos
- Pretensão e pedidos
- Documentos disponíveis
- Tese central (se já definida)
- Padrão visual do escritório (legal design, estrutura de cabeçalhos)

**Saídas esperadas:**
- Esqueleto da peça (cabeçalho → fatos → direito → pedidos → provas → valor da causa)
- Lista de documentos a juntar (com referência cruzada às alegações)
- Lista de julgados sugeridos (a confirmar via JusIA)
- Checklist final pré-protocolo

**Projetos que utilizam a skill:**
- Projeto Operacional (uso principal — Catharine)

# CLAUDE.md — Skill 05: Estruturar Peça para Protocolo

## Objetivo

Gerar esqueleto técnico padronizado de peça, alinhado ao tom do escritório, pronto para Catharine preencher.

---

## Contexto Necessário

Solicitar ao usuário antes de iniciar, caso não fornecido:

- Tipo de peça e vara
- Partes (qualificação básica)
- Fatos resumidos
- Pretensão e pedidos
- Documentos disponíveis
- Tese central (se já definida)
- Padrão visual do escritório (legal design, estrutura de cabeçalhos)

---

## Instruções de Execução

1. Montar a estrutura completa da peça com cabeçalhos, subtítulos e ordem técnica adequada à vara
2. Inserir parágrafos-âncora em cada seção (uma frase guia indicando o que vai ali)
3. Sugerir fundamentos legais aplicáveis (artigos específicos)
4. Sugerir 3 julgados recentes pertinentes — apenas referência, sinalizar: "confirmar via JusIA"
5. Listar documentos que devem instruir cada alegação
6. Indicar pedidos principais, subsidiários e tutela de urgência se aplicável
7. Marcar em destaque os pontos onde Catharine precisa decidir/incluir conteúdo específico

---

## Formato de Saída

**Esqueleto da peça:**
```
[CABEÇALHO]
Exmo. Sr. Juiz da X Vara de [comarca]

[QUALIFICAÇÃO DAS PARTES]
[ÂNCORA: qualificação completa do autor e réu]

I — DOS FATOS
[ÂNCORA: narrativa cronológica dos fatos]

II — DO DIREITO
[ÂNCORA: fundamentação legal e jurisprudencial]
Fundamentos sugeridos: [artigos]
Julgados sugeridos: [referências — confirmar via JusIA]

III — DOS PEDIDOS
[ÂNCORA: pedidos principais e subsidiários]
[Tutela de urgência se aplicável]

IV — DAS PROVAS
[ÂNCORA: documentos a juntar]

V — DO VALOR DA CAUSA
R$ [valor]
```

**Lista de documentos a juntar** (com referência cruzada às alegações)

**Checklist pré-protocolo:**
- [ ] Qualificação completa das partes
- [ ] Procuração assinada
- [ ] Documentos listados todos juntados
- [ ] Valor da causa definido
- [ ] Custas calculadas
- [ ] Revisão da Nilma realizada

---

## Casos de Uso

- Inicial de inventário → esqueleto com seções de habilitação de herdeiros e bens
- Contestação de divórcio litigioso → estrutura de impugnação por tópicos
- Recurso de apelação → estrutura com síntese da sentença e razões de reforma

---

## Limitações

- Esqueleto é minuta — toda peça exige preenchimento e revisão humana antes do protocolo
- Julgados sugeridos devem ser confirmados via JusIA antes de citar
- Não protocolar peça sem revisão e aprovação da Nilma

---

## Dependências Documentais

- DOC-0-perfil-do-escritorio.docx (padrão de peças e posicionamento)
- DOC-0-glossario-do-escritorio.docx (nomenclaturas corretas)

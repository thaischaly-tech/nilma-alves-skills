# CLAUDE.md — Skill 06: Revisar Peça para Protocolo

## Objetivo

Última camada de controle de qualidade antes do protocolo — técnica, formal, processual e estética. Emite veredito PRONTA / PRONTA APÓS AJUSTES / NÃO PRONTA.

---

## Contexto Necessário

Solicitar ao usuário antes de iniciar, caso não fornecido:

- Peça em versão "final"
- Documentos que vão instruir
- Vara/competência
- Padrão de identidade do escritório

---

## Instruções de Execução

1. **Revisão técnica:** enquadramento legal, jurisprudência citada (validade e atualização), coerência da tese
2. **Revisão processual:** competência, valor da causa, gratuidade/custas, qualificação completa, procuração, pedidos formais (citação, produção de provas, condenação em sucumbência)
3. **Revisão formal:** ortografia, concordância, regência, repetição, frases longas demais
4. **Revisão de coerência:** o que se afirma nos fatos é cobrado nos pedidos? Há prova citada para cada afirmação?
5. **Revisão de estética/legal design:** títulos, hierarquia, destaques, leitura escaneável
6. **Checklist de anexos:** cada documento citado está na lista de juntada?
7. **Lista de pendências obrigatórias** antes do protocolo
8. Emitir veredito final

---

## Formato de Saída

**Bloco 1 — Tabela de revisão**

| Tipo de revisão | Item | Trecho problemático | Sugestão |
|---|---|---|---|
| Técnica | | | |
| Processual | | | |
| Formal | | | |
| Coerência | | | |
| Estética | | | |

**Bloco 2 — Pendências obrigatórias** (sem isso, não protocola)
- [ ] item 1
- [ ] item 2

**Bloco 3 — Melhorias opcionais** (não impedem o protocolo)
- item 1
- item 2

**Bloco 4 — Veredito**
> **PRONTA** / **PRONTA APÓS AJUSTES** / **NÃO PRONTA**
> Justificativa:

---

## Casos de Uso

- Inicial de inventário pronta para protocolo → revisão completa antes de enviar
- Contestação em divórcio → checar se todos os documentos foram listados
- Recurso de apelação → verificar prazo e fundamentos de admissibilidade

---

## Limitações

- Revisão de jurisprudência citada é de validade formal — confirmar atualização via JusIA
- Veredito PRONTA não dispensa a assinatura e aprovação final da Nilma
- Não protocolar sem assinatura digital da advogada responsável

---

## Dependências Documentais

- DOC-0-perfil-do-escritorio.docx (padrão de qualidade e identidade visual das peças)

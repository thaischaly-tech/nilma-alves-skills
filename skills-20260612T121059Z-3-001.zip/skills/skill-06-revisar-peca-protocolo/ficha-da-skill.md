# Ficha da Skill

**Nome:** Skill 06 — Revisar peça para protocolo

**Objetivo:** Última camada de controle de qualidade antes do protocolo — técnica, formal, processual e estética. Emite veredito PRONTA / PRONTA APÓS AJUSTES / NÃO PRONTA.

**Quando utilizar:**
- Quando a peça estiver em versão "final" e prestes a ser protocolada
- Quando quiser garantir que nenhum item obrigatório foi esquecido
- Quando quiser um checklist completo antes do protocolo

**Entradas esperadas:**
- Peça em versão "final"
- Documentos que vão instruir
- Vara/competência
- Padrão de identidade do escritório

**Saídas esperadas:**
- Tabela: tipo de revisão | item | trecho problemático | sugestão
- Lista de pendências obrigatórias (sem isso não protocola)
- Lista de melhorias opcionais
- Veredito: PRONTA / PRONTA APÓS AJUSTES / NÃO PRONTA

**Projetos que utilizam a skill:**
- Projeto Operacional (uso principal — Catharine e Nilma)

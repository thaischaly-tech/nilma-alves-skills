# Ficha da Skill

**Nome:** Skill 02 — Analisar processo já protocolado

**Objetivo:** Diagnosticar processo em andamento (do escritório ou herdado de outro advogado) para identificar oportunidades, riscos, próximos movimentos e eventual reorientação estratégica.

**Quando utilizar:**
- Quando o escritório receber um processo herdado de outro advogado
- Quando um processo estiver parado e precisar de diagnóstico
- Quando a Nilma quiser saber o que fazer a seguir em um caso em andamento
- Quando precisar apresentar ao cliente a situação real do processo

**Entradas esperadas:**
- Cópia integral dos autos (PDF) ou peças principais (inicial, contestação, decisões, sentença se houver)
- Fase atual e última movimentação
- Objetivo do cliente hoje (mantém / acelera / reverte / acordo)

**Saídas esperadas:**
- Linha do tempo resumida
- Tabela: peça/decisão | data | impacto | observação
- Diagnóstico em 1 parágrafo (estado atual e probabilidade de êxito)
- Riscos imediatos (com prazo)
- 3 próximos movimentos recomendados, em ordem
- Recomendação ao cliente em 3 frases (linguagem leiga)

**Projetos que utilizam a skill:**
- Projeto Operacional (uso principal — Catharine e Nilma)

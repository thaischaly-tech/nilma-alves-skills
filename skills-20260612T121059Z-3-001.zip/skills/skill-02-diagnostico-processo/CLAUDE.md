# CLAUDE.md — Skill 02: Analisar Processo Já Protocolado

## Objetivo

Diagnosticar processo em andamento (do escritório ou herdado de outro advogado) para identificar oportunidades, riscos, próximos movimentos e eventual reorientação estratégica.

---

## Contexto Necessário

Solicitar ao usuário antes de iniciar, caso não fornecido:

- Cópia integral dos autos (PDF) ou peças principais (inicial, contestação, decisões, sentença se houver)
- Fase atual e última movimentação
- Objetivo do cliente hoje (mantém / acelera / reverte / acordo)

---

## Instruções de Execução

1. Mapear linha do tempo do processo (peças e decisões em ordem cronológica)
2. Identificar a tese atual da inicial e a tese da defesa
3. Listar todas as decisões interlocutórias e seus efeitos
4. Identificar provas produzidas, pendentes e perdidas (preclusão)
5. Apontar nulidades, contradições e oportunidades não exploradas
6. Avaliar prazos em curso e prazos críticos próximos
7. Comparar com a tese ideal: o que mudaria se o caso fosse iniciado hoje pelo escritório
8. Recomendar próximos 3 movimentos

---

## Formato de Saída

**Bloco 1 — Linha do tempo resumida**

**Bloco 2 — Tabela de movimentações**

| Peça/Decisão | Data | Impacto | Observação |
|---|---|---|---|

**Bloco 3 — Diagnóstico** (1 parágrafo — estado atual e probabilidade de êxito)

**Bloco 4 — Riscos imediatos** (com prazo para cada)

**Bloco 5 — Próximos 3 movimentos recomendados** (em ordem de prioridade)

**Bloco 6 — Recomendação ao cliente** (3 frases em linguagem leiga)

---

## Casos de Uso

- Processo de inventário herdado de advogado anterior — diagnóstico completo
- Ação de divórcio parada há 6 meses — identificar causa e próximos passos
- Processo imobiliário com decisão desfavorável — avaliar recurso vs. acordo

---

## Limitações

- Não inventar jurisprudência — sugerir referências e sinalizar: "confirmar via JusIA"
- Sinalizar sempre quando um prazo processual estiver envolvido
- Toda saída é minuta de diagnóstico — exige revisão e validação da Nilma antes de ser apresentada ao cliente

---

## Dependências Documentais

- DOC-0-perfil-do-escritorio.docx (posicionamento e critérios do escritório)
- DOC-0-glossario-do-escritorio.docx (nomenclaturas corretas)

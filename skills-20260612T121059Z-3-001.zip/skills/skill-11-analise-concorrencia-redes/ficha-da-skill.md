# Ficha da Skill

**Nome:** Skill 11 — Analisar concorrência nas redes sociais

**Objetivo:** Mapear o que escritórios concorrentes (Família/Sucessões em Guarujá, Santos, litoral SP e referências nacionais) estão fazendo nas redes, identificar lacunas e oportunidades de diferenciação.

**Quando utilizar:**
- Quando quiser entender o que os concorrentes estão postando
- Quando quiser encontrar oportunidades de conteúdo não exploradas pelo mercado
- Quando precisar de ângulos de diferenciação de posicionamento digital
- Para alimentar a Tarefa 02 (Pesquisa de mercado mensal)

**Entradas esperadas:**
- Lista de até 8 perfis concorrentes (Instagram, LinkedIn, TikTok)
- Período de análise (padrão: últimos 90 dias)
- Plataformas a considerar

**Saídas esperadas:**
- Tabela comparativa por perfil: tom / formato / frequência / engajamento médio / top 3 temas
- Padrões do mercado (o que todo mundo está fazendo igual — lista)
- Lacunas e oportunidades (o que ninguém aborda bem — lista)
- 5 ângulos para o escritório da Nilma ocupar com vantagem (com 1 ideia de post para cada)
- 3 formatos subexplorados pelos concorrentes locais

**Projetos que utilizam a skill:**
- Projeto Comercial (Tarefa 02 — Pesquisa mensal)
- Projeto Marketing

# CLAUDE.md — Skill 11: Analisar Concorrência nas Redes Sociais

## Objetivo

Mapear o que escritórios concorrentes (Família/Sucessões em Guarujá, Santos, litoral SP e referências nacionais) estão fazendo nas redes, identificar lacunas e oportunidades de diferenciação.

---

## Contexto Necessário

Solicitar ao usuário antes de iniciar, caso não fornecido:

- Lista de até 8 perfis concorrentes (Instagram, LinkedIn, TikTok)
- Período de análise (padrão: últimos 90 dias)
- Plataformas a considerar

---

## Instruções de Execução

1. Para cada perfil: analisar tom, frequência, formatos predominantes, temas mais frequentes, posts de maior engajamento
2. Identificar padrões e clichês do mercado (o que todo mundo está fazendo igual)
3. Identificar lacunas (temas que ninguém aborda bem ou que estão ditos com tom errado)
4. Identificar referências externas ao Guarujá que se destacam — e por quê
5. Sugerir 5 ângulos de conteúdo que o escritório da Nilma pode ocupar com vantagem
6. Sugerir 3 formatos subexplorados pelos concorrentes locais

---

## Formato de Saída

**Bloco 1 — Tabela comparativa por perfil**

| Perfil | Tom | Formato principal | Frequência | Engajamento médio | Top 3 temas |
|---|---|---|---|---|---|

**Bloco 2 — Padrões do mercado** (o que todo mundo está fazendo igual)
- item 1
- item 2

**Bloco 3 — Lacunas e oportunidades** (o que ninguém aborda bem)
- item 1
- item 2

**Bloco 4 — 5 ângulos para o escritório da Nilma ocupar**
1. Ângulo: [tema] → Ideia de post: [descrição]
2. ...

**Bloco 5 — 3 formatos a testar** (subexplorados pelos concorrentes locais)
1. formato 1
2. formato 2
3. formato 3

---

## Casos de Uso

- Análise mensal de 8 perfis concorrentes no litoral SP → relatório para a Tarefa 02
- Análise pontual antes de lançar uma série de conteúdos no Instagram
- Identificar por que um concorrente está crescendo mais rápido

---

## Limitações

- Usar apenas fontes verificáveis: redes públicas dos concorrentes
- Não afirmar o que não for diretamente observável
- Não fazer inferências especulativas sobre estratégia dos concorrentes
- Sinalizar quando uma informação precisar ser coletada manualmente pela equipe

---

## Dependências Documentais

- DOC-0-perfil-do-escritorio.docx (posicionamento do escritório para comparação)

# CLAUDE.md — Skill 01: Analisar Viabilidade do Caso

## Objetivo

Avaliar, antes de aceitar um caso, se ele é juridicamente viável, economicamente atrativo e estrategicamente alinhado ao posicionamento do escritório (Família, Sucessões, Imobiliário-regularização). Resultado: GO / NO-GO / GO CONDICIONADO com fundamentação.

---

## Contexto Necessário

Solicitar ao usuário antes de iniciar, caso não fornecido:

- Relato do cliente (texto, áudio transcrito ou anotação da consulta)
- Documentos disponíveis (certidões, contratos, decisões anteriores)
- Pretensão do cliente (o que ele quer alcançar)
- Tempo decorrido dos fatos
- Localização (comarca) e valor patrimonial estimado quando aplicável
- Perfil do Escritório (tom, ticket mínimo, casos que não atende)

---

## Instruções de Execução

1. Identificar a natureza jurídica predominante (família, sucessões, imobiliário, ou misto)
2. Mapear: causa de pedir, fundamento legal aplicável, provas existentes, provas faltantes
3. Avaliar prescrição/decadência, competência e legitimidade
4. Avaliar viabilidade probatória (o que precisa para vencer)
5. Avaliar risco de sucumbência e possibilidade de acordo
6. Avaliar custo-benefício para o cliente e ticket esperado para o escritório
7. Cruzar com critérios de NO-GO do escritório (ex.: cliente sem capacidade econômica, caso fora do nicho, conflito ético)
8. Emitir parecer GO / NO-GO / GO CONDICIONADO (a quê)

---

## Formato de Saída

**Bloco 1 — Resumo do caso** (até 5 linhas)

**Bloco 2 — Tabela de análise**

| Pontos fortes | Pontos fracos | Provas existentes | Provas faltantes | Riscos |
|---|---|---|---|---|

**Bloco 3 — Tese jurídica preliminar** (1 parágrafo)

**Bloco 4 — Estimativa de complexidade**
- Duração estimada:
- Complexidade: baixa / média / alta

**Bloco 5 — Honorários**
- Faixa sugerida:
- Formato de cobrança:

**Bloco 6 — Veredito**
> GO / NO-GO / GO CONDICIONADO
> Justificativa em 3 frases.

---

## Casos de Uso

- Caso novo de inventário com herdeiros em conflito → GO/NO-GO com tese preliminar
- Lead de divórcio litigioso com bens a partilhar → avaliação de viabilidade e honorários
- Pedido de regularização de imóvel sem documentação → GO CONDICIONADO com condições

---

## Limitações

- Não inventar jurisprudência — sugerir apenas referências e sinalizar: "confirmar via JusIA"
- Não fazer promessa de resultado ao cliente
- Não aceitar caso sem consultar o Perfil do Escritório para verificar critérios de NO-GO
- Toda saída é parecer técnico — exige validação final da Nilma antes de qualquer comprometimento com o cliente

---

## Dependências Documentais

- DOC-0-perfil-do-escritorio.docx (obrigatório — ticket mínimo, critérios de NO-GO, nicho)
- DOC-0-glossario-do-escritorio.docx (nomenclaturas corretas)

# Ficha da Skill

**Nome:** Skill 01 — Analisar viabilidade do caso

**Objetivo:** Avaliar, antes de aceitar um caso, se ele é juridicamente viável, economicamente atrativo e estrategicamente alinhado ao posicionamento do escritório (Família, Sucessões, Imobiliário-regularização). Resultado: GO / NO-GO / GO CONDICIONADO com fundamentação.

**Quando utilizar:**
- Quando um caso novo chegar e precisar de avaliação antes de aceitar
- Quando houver dúvida sobre enquadramento no nicho do escritório
- Quando for necessário avaliar risco de sucumbência ou viabilidade probatória
- Quando precisar definir tese jurídica preliminar e faixa de honorários

**Entradas esperadas:**
- Relato do cliente (texto, áudio transcrito ou anotação da consulta)
- Documentos disponíveis (certidões, contratos, decisões anteriores)
- Pretensão do cliente (o que ele quer alcançar)
- Tempo decorrido dos fatos
- Localização (comarca) e valor patrimonial estimado quando aplicável
- Perfil do Escritório (tom, ticket mínimo, casos que não atende)

**Saídas esperadas:**
- Resumo do caso em até 5 linhas
- Tabela: pontos fortes / pontos fracos / provas existentes / provas faltantes / riscos
- Tese jurídica preliminar (1 parágrafo)
- Estimativa de duração e complexidade (baixa/média/alta)
- Sugestão de honorários (faixa) e formato de cobrança
- Veredito final: GO / NO-GO / GO CONDICIONADO + justificativa em 3 frases

**Projetos que utilizam a skill:**
- Projeto Operacional (uso principal — Catharine e Nilma)
